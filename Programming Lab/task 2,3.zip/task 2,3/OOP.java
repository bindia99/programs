import java.util.Arrays;

/**
 * PRA2003 Task 2.3: Comparable objects.
 * @cambolbro (based on code from previous years)
 */

//-----------------------------------------------------------------------------

/**
 * Abstract superclass for deriving comparable object classes.
 */
abstract class Comparable 
{
    /**
     * @return True iff this object >= other.
     */
    public abstract boolean greaterThan(Comparable other);

    /** 
     * @return String description of object.
     */
    public abstract String toString();
}

//-----------------------------------------------------------------------------


class Song extends Comparable{

    private final String songname;
    private final int year;

    public Song(final String name, final int year){
        this.songname=name;
        this.year= year;
    }

    @Override
    public boolean greaterThan(Comparable other) {
        final Song otherSong = (Song)other;
        char ch1= songname.charAt(1);
        char ch2= otherSong.songname.charAt(1);
        if(year > otherSong.year){
            return true;
        }
        if(year == otherSong.year && Character.toLowerCase(ch1)>Character.toLowerCase(ch2)){
            return true;
        }

        return false;
    }

    @Override
    public String toString() {
        return songname;
    }
}

//-----------------------------------------------------------------------------/

class Student extends Comparable{
    private final String studname;
    private final double averageGrade;

    public Student(final String studname, final double averageGrade){
        this.studname= studname;
        this.averageGrade= averageGrade;
    }


    @Override
    public boolean greaterThan(Comparable other) {
        final Student otherStudent = (Student)other;
        char ch1= studname.charAt(1);
        char ch2= otherStudent.studname.charAt(1);
        if(averageGrade > otherStudent.averageGrade){
            return true;
        }
        if(averageGrade == otherStudent.averageGrade && Character.toLowerCase(ch1)>Character.toLowerCase(ch2)){
            return true;
        }

        return false;
    }


    @Override
    public String toString() {
        return studname;
    }
}


public class OOP 
{
	/**
	 * Sorts the elements in the array in ascending order.
	 */
    public static void bubbleSort(final Comparable[] array) 
    {
        boolean didSwap; 
        do 
        {
            didSwap = false; 
            for (int i = 0; i < array.length - 1; i++) 
                if (array[i].greaterThan(array[i + 1])) 
                { 
                    // Swap these two elements
                    final Comparable tmp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = tmp; 
                    didSwap = true;
                }
        } while (didSwap);
    }
	
    //---------------------------------------------------------
    
    /**
     * Main entry point.
     */
    public static void main(final String[] args)
    {
        final Comparable[] students = 
        { 
            new Student("Jerry",  8.7),
            new Student("Jerrry", 8.7), 
            new Student("David",  8.0),
            new Student("Gloria", 9.0) 
        };

        bubbleSort(students);
        System.out.println(Arrays.toString(students));
		
        final Comparable[] songs = 
        { 
            new Song("Seven Nation Army",   2003), 
            new Song("The Real Slim Shady", 2000), 
            new Song("Wonderwall",          1995),
            new Song("Karma Police",        1997) 
        };
        bubbleSort(songs);
        System.out.println(Arrays.toString(songs));
    }
}

