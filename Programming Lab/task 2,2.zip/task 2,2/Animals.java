/**
 * PRA2003 Task 2.2: Animal kingdom example.
 * @author cambolbro (based on code from previous years).
 */

/** 
 * Abstract animal base class.
 */
abstract class Animal 
{
    private final String name;
    private final double age;

    public double getAge() {
        return age;
    }

    public Animal(final String name, final double age)
    {
        this.name = name;
        this.age = age;
    }

    @Override	
    public String toString() 
    {
        return name + " goes " + makeNoise() +" and is "+ age+" years old.";
    }
	
    public abstract String makeNoise();
    public abstract boolean isOld();

    ;
}

//-----------------------------------------------------------------------------

/**
 * Concrete cat class based on Animal.
 */
class Cat extends Animal
{
    public Cat(final String name, final double age)
    {

        super(name, age);

    }
	
    public String makeNoise() 
    { 
        return "Meow"; 
    }

    @Override
    public boolean isOld() {
        return getAge() >= 10.0;

    }

}

//-----------------------------------------------------------------------------

/**
 * Concrete Dog class based on Animal.
 */
class Dog extends Animal {
    public Dog(final String name, final double age) {
        super(name, age);
    }

    public String makeNoise() {
        return "Woof";
    }

    @Override
    public boolean isOld() {
        return getAge() >= 0.8;
    }


//-----------------------------------------------------------------------------

    /**
     * Concrete bird class based on Animal.
     */
     class Bird extends Animal {
        public Bird(final String name, final double age) {

            super(name, age);

        }

        public String makeNoise() {
            return "Caw";
        }

        @Override
        public boolean isOld() {
           return getAge() >= 12;
        }

    }
//-----------------------------------------------------------------------------

    /**
     * Concrete robin class based on Bird.
     */
     class Robin extends Bird {
        public Robin(final String name, final double age) {
            super(name, age);
        }
    }

//-----------------------------------------------------------------------------

    /**
     * Concrete robin class based on Bird.
     */
    class Labrador extends Dog {
        public Labrador(final String name, final double age) {
            super(name, age);
        }
    }

//-----------------------------------------------------------------------------

    /**
     * Main test class.
     */
    public static class Animals {
        public static void main(final String[] args) {
            // Can't instantiate Animal directly because it's an abstract class:
            // Animal a = new Animal("Generic Animal");

            final Cat cat1 = new Cat("Fluffy", 8.0);
            final Animal cat2 = new Cat("Furry", 11.0);

            final Animal bird1 = new Bird("A Bird", 0.3);
            final Animal bird2 = new Robin("Rob", 0.9);
            final Animal dog1= new Dog("A Dog",0.7);
            final Animal dog2= new Labrador("Red",12.1);

            System.out.println(cat1);
            System.out.println(cat2);
            System.out.println(bird1);
            System.out.println(bird2);
            System.out.println(dog1);
            System.out.println(dog2);
            System.out.println(bird1.isOld());
            System.out.println(bird2.isOld());
            System.out.println(cat1.isOld());
            System.out.println(cat2.isOld());
            System.out.println(dog1.isOld());
            System.out.println(dog2.isOld());
        }
    }
}
