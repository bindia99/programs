import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * PRA2003: File for Week 4 tasks.
 * @author cambolbro (based on code from previous years).
 */

//=============================================================================

// Task 4.1 (a): Complete the missing State interface. 
interface TTTState{

    char getValue(final int row, final int col);

    public char currentPlayer();

    public void clickCell(final int row, final int col);


}

//=============================================================================

/**
 * Tic-Tac-Toe board that implements the game state.
 */
class TTTBoard implements TTTState 
{
   	public static final int Dim = 3;

    private char[][] board;
    private char player;

    //-------------------------------------------------------------------------
    
    /**
     * Constructor.
     */
    public TTTBoard() 
    {    	
        player = 'o';
        board  = new char[Dim][Dim];

        for (int r = 0; r < Dim; r++)
            for (int c = 0; c < Dim; c++)
                board[r][c] = '.';
    }

    //-------------------------------------------------------------------------
    // Overrides from State class
    
    @Override
    public char getValue(final int row, final int col) 
    {
        return board[row][col];
    }

    @Override
    public char currentPlayer() 
    {
        return player;
    }

    @Override
    public void clickCell(final int row, final int col) 
    {
        if (board[row][col] == '.') 
        {
            board[row][col] = player;
            nextPlayer();
        }
    }

    //-------------------------------------------------------------------------

    /**
     * Switch to next player.
     */
    private void nextPlayer() 
    {
    	player = (player == 'o') ? 'x' : 'o';
    }
}

//=============================================================================

// Task 4.1 (b): Implement the MouseEventTrapperClass:

class MouseEventTrapper implements MouseListener 
{
    private final TTTPanel panel;
    private final TTTState state;
    private int x;
    private int y;
    MouseEventTrapper(TTTPanel panel, TTTState state) {
        this.panel = panel;
        this.state = state;
    }


    @Override
    public void mouseClicked(MouseEvent e) {
       // final TTTBoard[][] board = new TTTBoard [3][3];
         x= (int) Math.floor(TTTBoard.Dim*(e.getY()-1)/ panel.getHeight());
         y= (int) Math.floor(TTTBoard.Dim*(e.getX()-1)/ panel.getWidth());

            panel.repaint();
            state.clickCell(x,y);
        System.out.println("Click at: (" + e.getX() + "," + e.getY() + ").");
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    //solves the problem of moving and clicking
    @Override
    public void mouseReleased(MouseEvent e) {
//System.out.println("Click at: (" + e.getX() + "," + e.getY() + ").");

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    // Add your code here
    // ...    
}

//=============================================================================

/**
 * Custom panel for our TTT game.
 */
class TTTPanel extends JPanel 
{

    private TTTState state;
    private BufferedImage[] images = new BufferedImage[2];





    public TTTPanel(TTTState state) throws IOException {


        this.state = state;
        try {
            images[0] = ImageIO.read(new File("dog-o.png"));
            images[1] = ImageIO.read(new File("dog-x.png"));
        } catch (Exception e) {
            System.out.println("An error happened, here comes some info to debug it:");
            e.printStackTrace();
        }
    }



    public void paint(Graphics g)
    {
        final int sx = getWidth()  / TTTBoard.Dim;
        final int sy = getHeight() / TTTBoard.Dim;
        for (int row = 0; row < TTTBoard.Dim; row++){
            for (int col = 0; col < TTTBoard.Dim; col++) {
                BufferedImage image = null;
                switch (state.getValue(row, col)) {
                    case 'o':
                        image = images[0];
                        break;
                    case 'x':
                        image = images[1];
                        break;
                }
                if (image != null) {
                    final int x = col * sx;
                    final int y = row * sy;
                    g.drawImage(
                            image, x, y, x + sx, y + sy, 0, 0,
                            image.getWidth(), image.getHeight(), null
                    );
                }
            }
        }
    }

    /**
     * Modify the appropriate label by setting its image icon.
     * The player should be either 'x' or 'o'.
     */
}

//=============================================================================

/**
 * Main GUI class.
 */
class GUI 
{
    private JFrame   frame;
    private TTTPanel panel;
    private TTTBoard board;

    /**
     * Initialise the GUI.
     */
    public void init() throws IOException {
        frame = new JFrame("Tic-Tac-Toe, MSC PRA2003 Edition");

        // Each cell is 100x100
        // Add 5 pixels for outer edge and 10 pixels for bar at top
        frame.setPreferredSize(new Dimension(305, 310));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the Tic-Tac-Doge board
        board = new TTTBoard();

        // Create the panel
        try {
            panel = new TTTPanel(board);
            panel.setSize(305, 310);
        }
        catch(Exception e){e.printStackTrace();}
        // Add the panel to the frame
        frame.add(panel);



        // Add the mouse event trapper to the panel
        panel.addMouseListener(new MouseEventTrapper(panel, board));

        frame.pack();
        frame.setVisible(true);
    }

    //-------------------------------------------------------------------------
    
    /**
     * Main entry point.
     */
    public static void main(final String[] args) throws IOException {
        GUI gui = new GUI();
        gui.init();
    }

}
