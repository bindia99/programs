/**
 * PRA2003 Task 3.1: program to catch nullpointer exception and Array index out of bounds exception.
 * Bindia Parekh
 */
public class Task31 {


    public static void main(String[] args){

        try {
            int[] array = null;
            System.out.println(array.length);
            int[] array1 = {2, 4, 6};
            array1[3] = 7;
        }

        //catches NullPointerException
        catch(NullPointerException e){System.out.println(e);}

        //catches ArrayIndexOutOfBoundsException
       
        catch(ArrayIndexOutOfBoundsException e){System.out.println(e);}
    }
}
