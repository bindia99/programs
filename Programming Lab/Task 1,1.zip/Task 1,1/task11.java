/**
 *   Class to add list values and calculate confidence .
 *   For PRA2003 (2020) task 1.1.
 *   Bindia Parekh
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class task11 {

    public static void main(final String[] args){
        StatKeeper listOb = new StatKeeper();


        //created list and added all values using Collections.addAll function found on URL: https://www.softwaretestinghelp.com/java-list-how-to-create-initialize-use-list-in-java/
        List<Integer> L = new ArrayList<Integer>();
        Collections.addAll(L,72, 81, 65, 93, 88, 21, 45, 28, 89, 67);

        for(int i=0;i < L.size(); i ++){
            int n = L.get(i);
            listOb.add(n);
        }

        System.out.println("Min Value is :"+listOb.getMin());
        System.out.println("Mean is :"+listOb.mean());
        System.out.println("Variance is :"+listOb.variance());
        System.out.println("Standard deviation is :"+listOb.standD());
        System.out.println(" 95% Confidence is  :"+listOb.confidence());

    }

}
