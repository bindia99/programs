import java.util.*; 

/**
 * A class to keep track of statistics for a list of numbers.
 * For PRA2003, based on code from previous years.
 * author: cambolbro, edited by Bindia Parekh
 */
class StatKeeper
{ 
	private List<Integer> list = new ArrayList<Integer>(); 

  	/** 
   	* Add an integer to the list
   	*/
  	public void add(final int x) 
  	{ 
	  list.add(x); 
  	}

  	/**
  	 * @return Minimum value in the list.
  	 */ 
  	public int getMin() 
  	{	 
  		int min = Integer.MAX_VALUE; 
    	for (int x : list)  
  			if (x < min)  
  				min = x; 
    	return min;
  	}

	/**
	 * @return Mean of the list.
	 */
	public double mean(){
		double t= 0;
		for(int i=0;i < list.size(); i ++){

			 t = t + list.get(i);
		}
		int n= list.size();
		double m= t/n;
		return m;
	}

	/**
	 * @return variance of the list.
	 */
	public double variance(){
		double t= 0;
		for(int i=0;i < list.size(); i ++){
        int value =list.get(i);
			t = t + Math.pow((value-mean()),2);
		}
		int n= list.size();
		double var = t/n;
		return var;
	}


	/**
	 * @return Standard Deviation of the list.
	 */
	public double standD(){
		double var = variance();
		double sd =  Math.sqrt(var);
		return sd;
	}

	/**
	 * @return 95% confidence level of the list.
	 */
	public double confidence(){
  		double prcnt = 1.96 * standD();
		int n= list.size();
  		double con = prcnt/Math.sqrt(n);

  		return con;
	}

}

