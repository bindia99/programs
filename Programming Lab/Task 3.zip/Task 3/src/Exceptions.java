/**
 * PRA2003 Task 3.1: Exceptions example.
 * @autho cambolbro (based on Eck book Sec 8.3.2)
 */

//-----------------------------------------------------------------------------

class IllegalArgumentException extends Exception 
{
    //This is a Class that extends the Exception.
    //Notice that Exceptions are like normal Classes
    //Which means that for custom exceptions, we can have fields, constructors,methods

    private String problem; //Only one field for this object

    IllegalArgumentException(String problem) {  //This is the constructor for these Exceptions
        this.problem = problem;
    }

    public String toString() {   //This Exception has one method.
        return "IllegalArgumentException: " + problem;
    }
}

//-----------------------------------------------------------------------------

/**
 * Demonstrates the use of our custom Exception.
 */
class Exceptions 
{  
	/**
	 * @return Larger of the two roots of the quadratic equation a*x*x + b*x + c = 0, 
	 *         provided it has any roots.
	 */
    public static double root( double a, double b, double c ) throws IllegalArgumentException 
    {
        if (a == 0) 
        {
            throw new IllegalArgumentException("a can't be zero.");
        }
        else 
        {
            double disc = b*b - 4*a*c;

            if (disc < 0)
                throw new IllegalArgumentException("Discriminant < zero.");

            return (-b + Math.sqrt(disc)) / (2*a);
        }
    }

    //-------------------------------------------------------------------------

    public static void main(String[] args) {
// error because Exception e catches all exceptions.
        try 
        {
            root(0, 5, 6);
        }
        catch (IllegalArgumentException e)
        {
            // This catches only IllegalArgumentExceptions
            System.out.println(e);
        }
        catch (Exception e) 
        {
            // This case catches every kind of exception
            System.out.println(e);
        }

        try
        {
            root(1, 0, 3);
        }
        catch (IllegalArgumentException e)
        {
            // This catches only IllegalArgumentExceptions
            System.out.println(e);
        }
    }    
}
