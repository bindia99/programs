import java.io.*;

/**
 * PRA2003: Task 3.3.
 * @author: cambolbro (based on previous years' code). 
 */
class FileReader 
{
	/** Name of input file. */
    private final String inFileName;

    /**
     * Constructor.
     */
    public FileReader(final String inFileName) 
    {
        this.inFileName = inFileName;
    }

    /**
     * Parse the file.
     */
    public void parse() throws IOException {
        FileWriter fw = new FileWriter("pepper-out.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        // Open the input stream using the input file name
        try (final BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(inFileName))))
        {
            String line = in.readLine();

            // Read line-by-line, printing out each line, until there are no more lines
            while (line != null) 
            {
                System.out.println(line);

                if(line.contains(" heat ")){
                    out.println(line);

                }
                line = in.readLine();
            }
            out.close();
        }
        catch (Exception e) 
        {
            System.out.println("An error happened, here comes some info to debug it:");
            e.printStackTrace();
            // All methods inherit this method (printStackTrace() from Throwable).
            // This method prints the stack trace of the Exception to System.err.
            // It tells us what happened and where in the code this happened.
        }
    }
    
    /**
     * Main entry point.
     */
    public static void main(String[] args) throws IOException 
    {
        FileReader fr = new FileReader("pepper.txt");
        fr.parse();
    }
}
