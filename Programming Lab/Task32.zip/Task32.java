/**
 * PRA2003 Task 3.1: program to catch nullpointer exception and Array index out of bounds exception.
 * Bindia Parekh
 */
public class Task32 {

    public static void methodA(int a){
      try {
          methodB(a + 5);
      }
      catch(Exception e){
          System.out.println(e.getMessage());
          System.out.println("StackTrace:");
          e.printStackTrace();

      }
    }

    public static void methodB(int b)throws Exception{
          methodC(b);

    }

    public static int methodC(int c) throws Exception{
       if(c==0){
        throw new Exception("c is zero.");
       }
       return c;
    }

    public static void main(String[] args) throws Exception {
       methodA(-5);
    }
}


